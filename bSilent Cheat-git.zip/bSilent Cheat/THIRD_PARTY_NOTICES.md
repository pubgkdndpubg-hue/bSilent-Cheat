# 第三方来源与许可

根目录 MIT 许可证适用于本仓库人工重构的 C++ 实现、接口、构建文件、测试组织和文档，不对原始二进制、原作者未恢复的工程或第三方代码重新授予许可。

## Dear ImGui

`jni/ImGui/` 保留 Dear ImGui v1.85 WIP 的源码及其原始通知。该目录使用自己的 MIT 许可证，见 [jni/ImGui/LICENSE.txt](jni/ImGui/LICENSE.txt)。其中 stb 文件中的独立许可和作者通知也保持原样。

上游：https://github.com/ocornut/imgui

ImGui 当前不参与核心构建，作为可选绘制依赖的源码保留。

## Dobby

本源码包不包含 Dobby 库二进制或其实现源码。`jni/Dobby/README.md` 仅提供上游入口，当前核心不依赖 Dobby。

## 测试数据

`tests/native_fixtures.hpp` 中的数值来自离线执行得到的 ARM64 输入/输出对照结果，未打包原始 SO、签名、仿真快照或加载器。
