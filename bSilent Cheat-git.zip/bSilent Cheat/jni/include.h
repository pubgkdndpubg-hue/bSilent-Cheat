#pragma once
// bSilent Cheat — public interface of the manually reconstructed, snapshot-based C++17 core.
#include "Draw.h"
#include "读写/ReadMemory.h"

namespace bsilent_recovered {
// 0x7143c; column-major matrix-vector product, ARM64 HFA Vec4 return.
Vec4 project_clip(const Matrix4&, Vec4);
std::optional<Vec2> world_to_screen(const Matrix4&, Vec3, Vec2 viewport);
Quaternion direction_quaternion(Vec3 delta);
// 0x6d2e0; the hook installation, rather than this callback, gates aim_enabled/type.
AimResult solve_shot(const RawConfig&, const SceneSnapshot&, const Shot&);
using OriginalShot = std::function<void(const Shot&, int)>;
AimResult dispatch_shot(const RawConfig&, const SceneSnapshot&, const Shot&, int flags,
                        const OriginalShot&);

// 0x75234: no blocking hit, or first blocking hit is the intended target.
bool visible_trace_result(std::uint64_t trace_flags, std::uintptr_t hit_actor,
                          std::uintptr_t target_actor);

struct HookRecord {
    std::string_view object_role;
    std::size_t table_slot;
    std::uint64_t callback_va;
    std::uint64_t original_global_va;
};
// Behavioral recovery of VM-protected 0x88b80 / 0x84be0 / 0x8b92c.
std::vector<HookRecord> startup_hooks(const std::array<std::uint64_t, 138>& table);
std::vector<HookRecord> esp_hooks(const std::array<std::uint64_t, 138>& table);
std::vector<HookRecord> shot_hooks(const std::array<std::uint64_t, 138>& table);
unsigned region_index(std::string_view package_name);
void apply_basic_only_startup(RawConfig&);

// Portable model of observed shadow-vtable transitions. This is not the original
// unbounded RTTI scan at 0x6d12c; callers supply the complete simulated table.
struct SimulatedObject { const std::vector<std::uint64_t>* table{}; };
class ShadowTableModel {
    SimulatedObject* object_{};
    const std::vector<std::uint64_t>* original_{};
    std::vector<std::uint64_t> shadow_;
public:
    ~ShadowTableModel();
    ShadowTableModel() = default;
    ShadowTableModel(const ShadowTableModel&) = delete;
    ShadowTableModel& operator=(const ShadowTableModel&) = delete;
    void attach(SimulatedObject&);
    std::uint64_t replace(std::size_t, std::uint64_t callback);
    void restore();
    bool attached_to(const SimulatedObject& object) const { return object_ == &object; }
};
} // namespace bsilent_recovered
