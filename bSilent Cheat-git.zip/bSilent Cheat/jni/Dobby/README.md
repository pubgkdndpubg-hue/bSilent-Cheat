# Dobby（可选依赖位置）

该目录保留项目结构中的 Dobby 位置。当前快照算法核心不调用 Dobby，因此构建不需要 `libdobby.a` 或 `libdobby.so`。

如扩展项目时需要 Dobby，请从上游获取匹配平台的源码，并保留对应许可证：

https://github.com/jmpews/Dobby
