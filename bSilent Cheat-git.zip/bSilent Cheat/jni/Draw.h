#pragma once
// bSilent Cheat — recovered bone and ESP callback interfaces.
#include "读写/Struct.h"
#include <functional>
#include <string_view>

namespace bsilent_recovered {
extern const std::array<std::string_view, 18> bone_initialization_order;
extern const std::array<std::string_view, 18> skeleton_point_order;
extern const std::array<std::array<unsigned, 2>, 17> skeleton_edges;
// 0x74c10; FName/bone index resolution occurs at runtime, not a fixed SDK bone index.
struct BoneProvider {
    virtual ~BoneProvider() = default;
    virtual int index_for_name(std::string_view) const = 0;
    virtual Vec3 world_translation(int index) const = 0;
};
Vec3 get_target_bone(const BoneProvider&, int selection);
using LineSink = std::function<void(Vec2, Vec2)>;
// 0x6978c; original enable byte at points + 0x90 must equal 1.
void draw_skeleton(const std::array<Vec2, 18>&, std::uint8_t enabled, const LineSink&);

// 0x84650: human-readable representation of the 0x1b8-byte player draw record.
struct Color { float r{},g{},b{},a{1}; };
struct EspPlayerRecord {
    std::uint8_t line_enabled{},name_enabled{},team_enabled{},distance_enabled{},health_enabled{},skeleton_enabled{};
    Vec2 top{};
    float bottom_y{};
    std::uint8_t bot{},visible{},in_vehicle{},knocked{};
    float health{},max_health{};
    std::array<Vec2,18> skeleton_points{};
    std::uint8_t skeleton_valid{};
    std::u16string_view name_text{},distance_text{}; // collection routine formats team/name strings
};
struct EspDrawContext {
    Vec2 viewport{};
    std::uint8_t center_x{},center_y{};
    std::function<Vec2(std::u16string_view)> measure_text;
    std::function<void(Vec2,Vec2,float,Color)> line;
    std::function<void(Vec2,std::u16string_view,Color)> text;
};
void draw_player_esp(const EspPlayerRecord&,const EspDrawContext&);
} // namespace bsilent_recovered
