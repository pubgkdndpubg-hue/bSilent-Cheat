#include "include.h"
#include <cmath>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace bsilent_recovered {
namespace {
Vec3 subtract(Vec3 a, Vec3 b) { return {a.x-b.x,a.y-b.y,a.z-b.z}; }
float length(Vec3 a) { return std::sqrt(a.x*a.x+a.y*a.y+a.z*a.z); }
bool zero(Vec3 a) { return a.x==0 && a.y==0 && a.z==0; }
}
Vec4 project_clip(const Matrix4& m, Vec4 p) {
    return {m[0]*p.x+m[4]*p.y+m[8]*p.z+m[12]*p.w,
            m[1]*p.x+m[5]*p.y+m[9]*p.z+m[13]*p.w,
            m[2]*p.x+m[6]*p.y+m[10]*p.z+m[14]*p.w,
            m[3]*p.x+m[7]*p.y+m[11]*p.z+m[15]*p.w};
}
std::optional<Vec2> world_to_screen(const Matrix4& m, Vec3 p, Vec2 viewport) {
    const Vec4 c=project_clip(m,{p.x,p.y,p.z,1});
    if (!(c.w>=0.001f)) return std::nullopt;
    const float hx=viewport.x*0.5f,hy=viewport.y*0.5f;
    return Vec2{hx+hx*c.x/c.w,hy-hy*c.y/c.w};
}
Quaternion direction_quaternion(Vec3 d) {
    const float pitch=std::atan2(d.z,std::sqrt(d.x*d.x+d.y*d.y));
    const float yaw=std::atan2(d.y,d.x);
    // The binary converts radians -> degrees -> half radians. This expression
    // is mathematically equivalent; last-bit rounding need not be identical.
    const float sp=std::sin(pitch*0.5f),cp=std::cos(pitch*0.5f);
    const float sy=std::sin(yaw*0.5f),cy=std::cos(yaw*0.5f);
    return {sp*sy,-sp*cy,cp*sy,cp*cy};
}
AimResult solve_shot(const RawConfig& cfg,const SceneSnapshot& scene,const Shot& input) {
    AimResult result{input,std::nullopt,std::nullopt};
    if (!scene.controller_present || !scene.owner_present || !scene.world_present ||
        !scene.level_present) return result;
    // The original assumes a valid menu-generated selection; the portable API
    // rejects invalid external input instead of performing an out-of-range read.
    if (cfg.target_bone<0 || cfg.target_bone>2) throw std::out_of_range("target_bone");
    float best=0;
    for (std::size_t i=0;i<scene.actors.size();++i) {
        const auto& a=scene.actors[i];
        if (!a.class_matches || !a.has_root || !a.has_mesh ||
            ((a.dead_flags|a.exclude_flags|a.other_flags)&1) || a.state==5 ||
            a.team==scene.owner_team) continue;
        const Vec3 p=a.aim_bones[static_cast<std::size_t>(cfg.target_bone)];
        if (zero(p)) continue;
        const auto screen=world_to_screen(scene.matrix,p,scene.viewport);
        if (!screen) continue;
        const float dx=screen->x-scene.viewport.x*0.5f,dy=screen->y-scene.viewport.y*0.5f;
        const float screen_distance=std::sqrt(dx*dx+dy*dy);
        if (cfg.angle_mode==1 && !(screen_distance<cfg.fov_radius)) continue;
        const float metric=cfg.preference==0 ? screen_distance : length(subtract(p,scene.owner_position));
        if (cfg.preference==1 && metric>45000.0f) continue;
        if (cfg.aim_visibility==1 && !a.visible) continue;
        // Preserve the state-dependent bot filter observed in the ARM64 code.
        const bool allow_bot=(a.state==0) && (((cfg.ignore_bot^1u)&1u)!=0);
        if (!allow_bot && (a.bot_flags&1u)) continue;
        if (!(a.health<=a.max_health)) continue;
        if (!(a.health>0) && (cfg.ignore_knocked&1u)) continue;
        if (result.target_index && best<=metric) continue; // first wins equal metric
        result.target_index=i;best=metric;
    }
    if (!result.target_index) return result;
    const auto& target=scene.actors[*result.target_index];
    Vec3 point=target.aim_bones[static_cast<std::size_t>(cfg.target_bone)];
    if (zero(point)) return result;
    if (cfg.prediction==1) {
        if (scene.bullet_speed_present) result.replacement_bullet_speed=600000.0f;
    } else if (cfg.prediction==0 && scene.bullet_speed_present && scene.bullet_speed!=0) {
        const float time=length(subtract(point,input.origin))/scene.bullet_speed;
        point={point.x+target.velocity.x*time,point.y+target.velocity.y*time,
               point.z+target.velocity.z*time};
    }
    // No gravity term was found in this routine.
    result.shot.rotation=direction_quaternion(subtract(point,input.origin));
    return result;
}
AimResult dispatch_shot(const RawConfig& cfg,const SceneSnapshot& scene,const Shot& input,
                        int flags,const OriginalShot& original) {
    auto result=solve_shot(cfg,scene,input);
    original(result.shot,flags);
    return result;
}
float decode_speed(std::uint32_t encoded,std::uint8_t key) {
    const std::uint32_t bits=encoded^(static_cast<std::uint32_t>(key)*0x01010101u);
    float value;std::memcpy(&value,&bits,4);return value;
}
std::uint32_t encode_speed(float value,std::uint8_t key) {
    std::uint32_t bits;std::memcpy(&bits,&value,4);
    return bits^(static_cast<std::uint32_t>(key)*0x01010101u);
}
float read_speed_cells(const std::vector<std::uint8_t>& cells) {
    if (cells.size()<=0x30) throw std::out_of_range("speed header");
    const std::size_t at=static_cast<std::size_t>(cells[0x30])*6;
    if (at+5>cells.size()) throw std::out_of_range("speed cell");
    std::uint32_t bits;std::memcpy(&bits,cells.data()+at,4);
    return decode_speed(bits,cells[at+4]);
}
void write_speed_cells(std::vector<std::uint8_t>& cells,float speed) {
    if (cells.size()<=0x30) throw std::out_of_range("speed header");
    const std::size_t at=static_cast<std::size_t>(cells[0x30])*6;
    if (at+5>cells.size()) throw std::out_of_range("speed cell");
    const auto bits=encode_speed(speed,cells[at+4]);std::memcpy(cells.data()+at,&bits,4);
}
bool visible_trace_result(std::uint64_t trace,std::uintptr_t hit,std::uintptr_t target) {
    return !(trace&1u) || hit==target;
}
const std::array<std::string_view,18> bone_initialization_order={
    "head","neck_01","spine_03","upperarm_r","upperarm_l","lowerarm_r","lowerarm_l",
    "hand_r","hand_l","spine_02","spine_01","pelvis","thigh_r","thigh_l",
    "calf_r","calf_l","foot_r","foot_l"};
const std::array<std::string_view,18> skeleton_point_order={
    "head","neck_01","spine_03","upperarm_r","lowerarm_r","hand_r",
    "upperarm_l","lowerarm_l","hand_l","spine_02","spine_01","pelvis",
    "thigh_r","calf_r","foot_r","thigh_l","calf_l","foot_l"};
const std::array<std::array<unsigned,2>,17> skeleton_edges={{{0,1},{1,2},{1,3},{3,4},
    {4,5},{1,6},{6,7},{7,8},{2,9},{9,10},{10,11},{11,12},{12,13},{13,14},
    {11,15},{15,16},{16,17}}};
Vec3 get_target_bone(const BoneProvider& provider,int selection) {
    if (selection<0 || selection>2) throw std::out_of_range("target_bone");
    const int index=provider.index_for_name(bone_initialization_order[static_cast<std::size_t>(selection)]);
    return index==-1 ? Vec3{} : provider.world_translation(index);
}
void draw_skeleton(const std::array<Vec2,18>& points,std::uint8_t enabled,const LineSink& line) {
    if (enabled!=1) return;
    for (auto edge:skeleton_edges) line(points[edge[0]],points[edge[1]]);
}
void draw_player_esp(const EspPlayerRecord& p,const EspDrawContext& ctx) {
    // Raw byte bot==1 is used by this renderer; the selector uses bot_flags&1.
    const Color color=p.visible ? Color{0.0318960324f,0.679542482f,0.0318960324f,1}
                                : (p.bot==1 ? Color{1,1,1,1} : Color{1,0,0,1});
    if (p.line_enabled==1)
        ctx.line({ctx.viewport.x*0.5f,ctx.viewport.y/6.0f},{p.top.x,p.top.y-10},1,color);
    if (p.skeleton_enabled==1)
        draw_skeleton(p.skeleton_points,p.skeleton_valid,[&](Vec2 a,Vec2 b){ctx.line(a,b,1,color);});
    if (p.in_vehicle&1u) return;
    if (p.health_enabled==1) {
        const float left=p.top.x-17.5f,right=p.top.x+17.5f,y=p.top.y-5;
        const float fill=left+(p.health/p.max_health)*35.0f;
        const Color filled=p.knocked ? Color{0.904661179f,0.0561284907f,0.0368894488f,1}
                                     : Color{0.0722718462f,0.428690493f,0.0802198201f,1};
        const Color empty=p.knocked ? Color{0.242281124f,0.00402471703f,0.0742135644f,1}
                                    : Color{0,0.0742135644f,0.0512694567f,1};
        ctx.line({left,y},{fill,y},5,filled);ctx.line({right,y},{fill,y},5,empty);
    }
    auto label=[&](float y,std::u16string_view text) {
        Vec2 offset{};
        if ((ctx.center_x|ctx.center_y)!=0) {
            const Vec2 size=ctx.measure_text(text);
            offset.x=static_cast<float>((static_cast<int>(size.x)/2)*ctx.center_x);
            offset.y=static_cast<float>((static_cast<int>(size.y)/2)*ctx.center_y);
        }
        ctx.text({p.top.x-offset.x,y-offset.y},text,{1,1,1,1});
    };
    if (p.name_enabled==1) label(p.bottom_y+10,p.name_text);
    if (p.distance_enabled==1) label(p.bottom_y+30-(p.name_enabled==0?20.0f:0.0f),p.distance_text);
}
std::vector<HookRecord> startup_hooks(const std::array<std::uint64_t,138>& t) {
    return {{"engine singleton",static_cast<std::size_t>(t[0x98/8]),0x71fb8,0x16f718},
            {"viewport object",static_cast<std::size_t>(t[0xa8/8]),0x80978,0},
            {"input object + table[0x1c8]",static_cast<std::size_t>(t[0xb0/8]),0x73844,0x16f728},
            {"input object + table[0x1c8]",static_cast<std::size_t>(t[0xb8/8]),0x74cd0,0x16f738},
            {"input object + table[0x1c8]",static_cast<std::size_t>(t[0xc0/8]),0x84588,0x16f748}};
}
std::vector<HookRecord> esp_hooks(const std::array<std::uint64_t,138>& t) {
    return {{"local player associated render object",static_cast<std::size_t>(t[0xa0/8]),0x89ccc,0x16f6d8},
            {"restore/passthrough",static_cast<std::size_t>(t[0x90/8]),0x8c170,0x16f6e8}};
}
std::vector<HookRecord> shot_hooks(const std::array<std::uint64_t,138>& t) {
    return {{"shot-associated object",static_cast<std::size_t>(t[0xc8/8]),0x6d2e0,0x16f6f8},
            {"restore/passthrough",static_cast<std::size_t>(t[0x90/8]),0x7c5fc,0x16f708}};
}
unsigned region_index(std::string_view package) {
    if (package=="com.tencent.ig") return 1;
    if (package=="com.pubg.imobile") return 2;
    if (package=="com.rekoo.pubgm") return 3;
    if (package=="com.vng.pubgmobile") return 4;
    if (package=="com.pubg.krmobile") return 5;
    return 0;
}
void apply_basic_only_startup(RawConfig& c) {
    if (c.basic_only) { c.esp_enabled=1;c.startup_flag=1;c.aim_enabled=0;c.misc_enabled=0; }
}
ShadowTableModel::~ShadowTableModel() { restore(); }
void ShadowTableModel::attach(SimulatedObject& object) {
    if (object_==&object) return;
    restore();
    if (!object.table) throw std::invalid_argument("missing simulated vtable");
    original_=object.table;shadow_=*original_;object_=&object;object_->table=&shadow_;
}
std::uint64_t ShadowTableModel::replace(std::size_t slot,std::uint64_t callback) {
    if (!object_) throw std::logic_error("no simulated object attached");
    if (slot>=shadow_.size()) throw std::out_of_range("simulated vtable slot");
    const auto original=(*original_)[slot];shadow_[slot]=callback;return original;
}
void ShadowTableModel::restore() {
    if (object_) object_->table=original_;
    object_=nullptr;original_=nullptr;shadow_.clear();
}
} // namespace bsilent_recovered
