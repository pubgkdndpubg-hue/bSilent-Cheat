#pragma once
// bSilent Cheat — recovered math types, config layout and offline scene snapshots.
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

namespace bsilent_recovered {
struct Vec2 { float x{}, y{}; };
struct Vec3 { float x{}, y{}, z{}; };
struct Vec4 { float x{}, y{}, z{}, w{}; };
struct Quaternion { float x{}, y{}, z{}, w{1}; };
using Matrix4 = std::array<float, 16>;

// Config pointer: GOT VA 0x144db0 -> data VA 0x16e210.
// Names are analyst-assigned; byte positions come from menu bindings and consumers.
#pragma pack(push, 1)
struct RawConfig {
    std::uint8_t esp_enabled;        // 00
    std::uint8_t startup_flag;       // 01; basic-only startup writes this to 1
    std::uint8_t aim_enabled;        // 02
    std::uint8_t reserved03;         // 03
    std::int32_t aim_type;           // 04; PSilent = 1
    std::uint8_t misc_enabled;       // 08
    std::uint8_t autoload;           // 09
    std::uint8_t esp_line;           // 0a
    std::uint8_t esp_name;           // 0b
    std::uint8_t esp_team;           // 0c
    std::uint8_t esp_distance;       // 0d
    std::uint8_t esp_health;         // 0e
    std::uint8_t esp_skeleton;       // 0f
    std::uint8_t esp_visibility;     // 10
    std::uint8_t esp_vehicle;        // 11
    std::uint8_t reserved12[2];      // 12
    std::uint8_t aim_visibility;     // 14
    std::uint8_t ignore_knocked;     // 15
    std::uint8_t ignore_bot;         // 16
    std::uint8_t reserved17;         // 17
    std::int32_t angle_mode;         // 18; 0 unrestricted, 1 screen FOV radius
    float fov_radius;               // 1c; pixels
    std::int32_t preference;         // 20; 0 screen distance, 1 world distance
    std::int32_t target_bone;        // 24; 0 head, 1 neck_01, 2 spine_03
    std::int32_t prediction;         // 28; 0 velocity, 1 instant, 2 unchanged point
    std::uint8_t bypass_angle;       // 2c
    std::uint8_t reserved2d[3];      // 2d
    std::uint8_t bunny_hop;          // 30
    std::uint8_t basic_only;         // 31
    std::uint8_t reserved32[2];      // 32
};
#pragma pack(pop)
static_assert(sizeof(RawConfig) == 0x34);
static_assert(offsetof(RawConfig, aim_visibility) == 0x14);
static_assert(offsetof(RawConfig, fov_radius) == 0x1c);
static_assert(offsetof(RawConfig, prediction) == 0x28);
static_assert(offsetof(RawConfig, basic_only) == 0x31);

struct ActorSnapshot {
    bool class_matches{true};
    bool has_root{true};
    bool has_mesh{true};
    std::int32_t team{};
    std::uint8_t dead_flags{}, exclude_flags{}, other_flags{}, state{}, bot_flags{};
    float health{100}, max_health{100};
    std::array<Vec3, 3> aim_bones{};
    Vec3 velocity{};                 // resolved via vehicle / alternate component / root
    bool visible{true};
};
struct Shot { Quaternion rotation{}; Vec3 origin{}; };
struct SceneSnapshot {
    Matrix4 matrix{};
    Vec2 viewport{};
    Vec3 owner_position{};
    std::int32_t owner_team{};
    bool controller_present{true}, owner_present{true}, world_present{true}, level_present{true};
    bool bullet_speed_present{true};
    float bullet_speed{};
    std::vector<ActorSnapshot> actors;
};
struct AimResult {
    Shot shot;
    std::optional<std::size_t> target_index;
    std::optional<float> replacement_bullet_speed;
};
} // namespace bsilent_recovered
