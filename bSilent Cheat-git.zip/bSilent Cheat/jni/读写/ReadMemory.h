#pragma once
// bSilent Cheat — checked reads/writes of caller-owned byte buffers; no process-memory IO.
#include <cstdint>
#include <vector>

namespace bsilent_recovered {
float decode_speed(std::uint32_t encoded_bits, std::uint8_t key);
std::uint32_t encode_speed(float speed, std::uint8_t key);
float read_speed_cells(const std::vector<std::uint8_t>& cells);
void write_speed_cells(std::vector<std::uint8_t>& cells, float speed);
} // namespace bsilent_recovered
