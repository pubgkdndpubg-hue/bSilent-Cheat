LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
# Project display name: bSilent Cheat. NDK module identifiers cannot contain spaces.
LOCAL_MODULE := bsilent_cheat
LOCAL_CPP_EXTENSION := .cpp
LOCAL_SRC_FILES := Main.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)
LOCAL_CPPFLAGS := -std=c++17 -fexceptions -frtti -Wall -Wextra
LOCAL_LDLIBS := -lm
# ImGui/Dobby are supplied reference dependencies, not part of this offline core.
include $(BUILD_SHARED_LIBRARY)
