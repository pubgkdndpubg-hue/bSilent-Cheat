#include "native_fixtures.hpp"
#include <cmath>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
namespace {
unsigned assertions=0;
void check(bool condition,const std::string& name) {
    ++assertions;
    if (!condition) throw std::runtime_error(name);
}
bool near(float a,float b) { return std::abs(a-b)<=0.00001f*(1+std::abs(b)); }
bool equal(Quaternion a,Quaternion b) { return near(a.x,b.x)&&near(a.y,b.y)&&near(a.z,b.z)&&near(a.w,b.w); }
bool equal(Vec4 a,Vec4 b) { return near(a.x,b.x)&&near(a.y,b.y)&&near(a.z,b.z)&&near(a.w,b.w); }
struct FakeBones final:BoneProvider {
    int index_for_name(std::string_view name) const override {
        if (name=="head") return 11;
        if (name=="neck_01") return 22;
        return -1;
    }
    Vec3 world_translation(int index) const override { return {100,static_cast<float>(index),5}; }
};
}
int main() {
    try {
        unsigned n=0;
        for (const auto& fixture:captured_matrices())
            check(equal(project_clip(fixture.matrix,fixture.input),fixture.expected),"native matrix "+std::to_string(n++));
        for (const auto& fixture:captured_shots()) {
            unsigned callbacks=0;
            const auto result=dispatch_shot(fixture.config,fixture.scene,fixture.input,7,
                [&](const Shot& shot,int flags) {
                    ++callbacks;check(flags==7,std::string(fixture.name)+" flags");
                    check(equal(shot.rotation,fixture.expected),std::string(fixture.name)+" callback quaternion");
                });
            check(equal(result.shot.rotation,fixture.expected),std::string(fixture.name)+" ARM64 quaternion");
            check(callbacks==1,std::string(fixture.name)+" callback count");
            check((result.target_index?static_cast<int>(*result.target_index):-1)==fixture.selected,
                  std::string(fixture.name)+" target");
            const bool instant=fixture.config.prediction==1&&fixture.selected>=0&&fixture.scene.bullet_speed_present;
            check(result.replacement_bullet_speed.has_value()==instant,std::string(fixture.name)+" speed write presence");
            if (instant) check(*result.replacement_bullet_speed==600000.0f,"native instant speed");
        }
        check(visible_trace_result(0,2,1),"visibility no hit");
        check(visible_trace_result(1,1,1),"visibility target hit");
        check(!visible_trace_result(1,2,1),"visibility blocked");
        std::vector<std::uint8_t> cells(0x80);cells[0x30]=2;cells[16]=0x93;
        write_speed_cells(cells,600000.0f);
        std::uint32_t bits;std::memcpy(&bits,cells.data()+12,4);
        check((bits^0x93939393u)==0x49127c00u,"captured exact instant float bits");
        check(read_speed_cells(cells)==600000.0f,"captured cell selector 2");
        std::array<Vec2,18> points{};
        for (unsigned i=0;i<points.size();++i) points[i]={static_cast<float>(2*i),static_cast<float>(2*i+1)};
        unsigned edge=0;
        draw_skeleton(points,1,[&](Vec2 a,Vec2 b) {
            const auto indices=skeleton_edges.at(edge++);
            check(a.x==2*indices[0]&&a.y==2*indices[0]+1&&b.x==2*indices[1]&&b.y==2*indices[1]+1,"native skeleton edge");
        });
        check(edge==17,"17 native skeleton lines");
        draw_skeleton(points,0,[&](Vec2,Vec2){++edge;});check(edge==17,"native skeleton disabled");
        check(bone_initialization_order.front()=="head"&&bone_initialization_order.back()=="foot_l","native 18 bone names");
        FakeBones bones;check(get_target_bone(bones,1).y==22,"runtime bone name resolution");
        check(get_target_bone(bones,2).x==0,"missing bone zero");
        check(region_index("com.tencent.ig")==1&&region_index("com.pubg.imobile")==2&&
              region_index("com.rekoo.pubgm")==3&&region_index("com.vng.pubgmobile")==4&&
              region_index("com.pubg.krmobile")==5,"five captured regions");
        check(region_index("example.unsupported")==0,"unknown region");
        std::array<std::uint64_t,138> table{};
        table[0x98/8]=95;table[0xa8/8]=2;table[0xb0/8]=23;table[0xb8/8]=24;
        table[0xc0/8]=25;table[0xa0/8]=245;table[0x90/8]=22;table[0xc8/8]=173;
        const auto startup=startup_hooks(table),esp=esp_hooks(table),shot=shot_hooks(table);
        check(startup.size()==5&&startup[0].table_slot==95&&startup[0].callback_va==0x71fb8,"captured frame hook");
        check(startup[1].table_slot==2&&startup[1].callback_va==0x80978,"captured menu hook");
        check(startup[2].table_slot==23&&startup[3].table_slot==24&&startup[4].table_slot==25,"captured input hooks");
        check(esp[0].table_slot==245&&esp[0].callback_va==0x89ccc,"captured ESP hook");
        check(shot[0].table_slot==173&&shot[0].callback_va==0x6d2e0,"captured shot hook");
        std::vector<std::uint64_t> original(400);
        for (unsigned i=0;i<original.size();++i) original[i]=0x800010000ull+4*i;
        SimulatedObject object{&original};ShadowTableModel shadow;shadow.attach(object);
        for (const auto& hook:shot) shadow.replace(hook.table_slot,hook.callback_va);
        check((*object.table)[173]==0x6d2e0&&(*object.table)[22]==0x7c5fc,"native two-slot shadow changes");
        const auto* attached=object.table;shadow.attach(object);check(object.table==attached,"native repeated enable");
        shadow.restore();check(object.table==&original,"native disable restores original table");
        RawConfig config{};config.basic_only=1;config.aim_enabled=1;config.misc_enabled=1;
        apply_basic_only_startup(config);
        check(config.esp_enabled==1&&config.startup_flag==1&&config.aim_enabled==0&&config.misc_enabled==0,"basic startup normalization");
        // Positions and colors below were captured from ARM64 VA 0x84650.
        struct Line { Vec2 from,to;float thickness;Color color; };
        std::vector<Line> lines;std::vector<Vec2> labels;
        EspDrawContext draw{{1000,600},0,0,[](std::u16string_view){return Vec2{20,10};},
            [&](Vec2 a,Vec2 b,float thickness,Color color){lines.push_back({a,b,thickness,color});},
            [&](Vec2 where,std::u16string_view,Color){labels.push_back(where);}};
        EspPlayerRecord player{};player.line_enabled=1;player.health_enabled=1;player.skeleton_enabled=1;
        player.top={300,200};player.bottom_y=400;player.health=25;player.max_health=100;
        player.skeleton_valid=1;player.skeleton_points=points;
        draw_player_esp(player,draw);
        check(lines.size()==20,"native ESP line, 17 bones, two health segments");
        check(lines[0].from.x==500&&lines[0].from.y==100&&lines[0].to.x==300&&lines[0].to.y==190,"native ESP snapline geometry");
        check(lines[0].color.r==1&&lines[0].color.g==0&&lines[0].color.b==0,"native invisible human red");
        check(lines[18].from.x==282.5f&&lines[18].to.x==291.25f&&lines[19].from.x==317.5f&&lines[19].to.x==291.25f,"native 25 percent health geometry");
        check(lines[18].thickness==5&&near(lines[18].color.r,0.0722718462f),"native live health thickness/color");
        player.bot=1;lines.clear();draw_player_esp(player,draw);check(lines[0].color.g==1&&lines[0].color.b==1,"native bot white");
        player.bot=0;player.visible=1;lines.clear();draw_player_esp(player,draw);check(near(lines[0].color.g,0.679542482f),"native visible green");
        player.visible=0;player.in_vehicle=1;lines.clear();draw_player_esp(player,draw);check(lines.size()==18,"native vehicle skips health and labels");
        player.in_vehicle=0;player.knocked=1;player.health=50;lines.clear();draw_player_esp(player,draw);
        check(lines[18].to.x==300&&near(lines[18].color.r,0.904661179f)&&near(lines[19].color.r,0.242281124f),"native knocked health");
        player.name_enabled=1;player.distance_enabled=1;player.name_text=u"Alice";player.distance_text=u"123m";
        draw.center_x=1;draw.center_y=1;labels.clear();draw_player_esp(player,draw);
        check(labels.size()==2&&labels[0].x==290&&labels[0].y==405&&labels[1].x==290&&labels[1].y==425,"native centered name and distance");
        player.name_enabled=0;draw.center_x=0;draw.center_y=0;labels.clear();draw_player_esp(player,draw);
        check(labels.size()==1&&labels[0].x==300&&labels[0].y==410,"native distance without name");
        std::cout<<"PASS "<<assertions<<" assertions; 10 matrix fixtures and 32 captured ARM64 shot fixtures\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr<<"FAIL after "<<assertions<<" assertions: "<<error.what()<<'\n';return 1;
    }
}
