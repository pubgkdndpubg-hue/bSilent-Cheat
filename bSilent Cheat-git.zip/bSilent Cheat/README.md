# bSilent Cheat

bSilent 核心算法的 C++17 人工恢复实现，按 `jni/` 结构组织。接口使用离线场景快照，便于阅读、构建和测试；实现范围见 [恢复说明](docs/RECOVERY.md)。

## 目录

```text
bSilent Cheat/
├── jni/
│   ├── Android.mk
│   ├── Application.mk
│   ├── Main.cpp
│   ├── include.h
│   ├── Draw.h
│   ├── 读写/
│   │   ├── Struct.h
│   │   └── ReadMemory.h
│   ├── ImGui/             # 可选绘制依赖源码及原许可证
│   └── Dobby/             # 可选依赖位置及上游说明
├── tests/
├── docs/
├── .github/workflows/     # GitHub 上的 CMake 构建和测试
├── CMakeLists.txt
├── LICENSE
└── THIRD_PARTY_NOTICES.md
```

## 构建与测试

需要 CMake 3.16+ 和 C++17 编译器：

```sh
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

直接使用 GCC 或 Clang：

```sh
c++ -std=c++17 -O2 -Wall -Wextra -Ijni jni/Main.cpp tests/recovery_tests.cpp -o recovery_tests
./recovery_tests
```

Windows 可将 `c++` 换成 Zig 0.13.0 的 `zig c++`，输出名改为 `recovery_tests.exe`。测试通过时输出：

```text
PASS 252 assertions; 10 matrix fixtures and 32 captured ARM64 shot fixtures
```

## 核心接口

包含 `jni/include.h`，命名空间为 `bsilent_recovered`。`Main.cpp` 集中实现算法，`Draw.h` 声明绘制接口，`读写/Struct.h` 定义快照与配置数据。

- `solve_shot` / `dispatch_shot`：目标筛选、预测和发射四元数。
- `project_clip` / `world_to_screen`：矩阵变换和屏幕投影。
- `get_target_bone` / `draw_skeleton`：运行时骨骼名及骨骼连线。
- `draw_player_esp`：射线、骨骼、血条和文字回调。
- `RawConfig`、区域映射、Basic Only 和 Hook 行为模型。

## Android NDK

在项目根目录执行：

```sh
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=./jni/Android.mk NDK_APPLICATION_MK=./jni/Application.mk
```

配置目标为 `arm64-v8a` / Android 21，输出核心库 `libbsilent_cheat.so`。该目标仅构建离线算法库，未接入完整游戏或 Zygisk 模块；NDK 配置尚未实编验证。

Windows 的 ndk-build 对路径空格有限制，构建时可使用 `C:/dev/bsilent_cheat` 这样的无空格路径，项目显示名称仍为 **bSilent Cheat**。

## Git 仓库

解压后，将本目录的文件作为仓库根目录提交即可。`.gitignore` 已排除编译产物、压缩包和本地日志；`.gitattributes` 配置了源码换行。构建依赖是 C++17 标准库，ImGui 和 Dobby 均未加入核心编译。

## 许可

人工重构实现及本仓库新增构建文件、测试组织和文档采用 [MIT](LICENSE) 许可。第三方来源及许可范围见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
